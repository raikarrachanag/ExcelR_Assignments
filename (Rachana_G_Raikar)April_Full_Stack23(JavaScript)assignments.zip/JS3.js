
	// Function declaration
	function add(a, b) {		
		console.log(a + b);
	}
	
	// Calling a function
	add(2, 3);


	// Function Expression
	const add2 = function(c, d) {
		console.log(c+d);
	}
    

 
	// Single line of code
	let add3= (e, f) => e + f;
	
	console.log(add3(3, 2));


	// Multiple line of code
	const great = (g, h) => {
		if (g > h)
			return "g is greater";
		else
			return "h is greater";
	}
	
	console.log(great(3,5));




	
	// Calling function
	add(2, 3);

