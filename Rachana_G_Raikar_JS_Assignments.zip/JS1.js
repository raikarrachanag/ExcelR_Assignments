
const cars = ["BMW", "Volvo", "Saab", "Ford"];


let i = 1;
let len = cars.length;
let text = "";
while (i < 6) {
  text += "<br>While loop iteration " + i;
  i++;
}
document.getElementById("demo").innerHTML = text;

let j=1;
let len1=cars.length;
let text1="";

for (; j < 6; ) {
  text += "<br> For loop iteration is " +j;
  j++;
}
document.getElementById("demo").innerHTML = text;

let k=1;
let len2=cars.length;
let text2 = "";

do {
  text += "<br> Do-While loop iteration " +k;
  k++;
}
while (k < 6);
document.getElementById("demo").innerHTML = text;