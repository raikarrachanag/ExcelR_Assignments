function greet(name) {
	console.log(`Hello, ${name}`);
  }
  
  greet("Alice"); // Output: Hello, Alice!

  const greet1= function(name) {
	console.log(`Hello, ${name}`);
  };
  
  greet1("Bob"); // Output: Hello, Bob!

  const greet3= (name) => {
	console.log(`Hello, ${name}`);
  };
  
  greet3("Charlie"); // Output: Hello, Charlie!

  const greet4 = new Function("name", "console.log(`Hello, ${name}`);");

  greet4("Dave"); // Output: Hello, Dave!

  (function(name) {
	console.log(`Hello, ${name}`);
  })("Eve"); // Output: Hello, Eve!

  function* helloGenerator() {
	yield "Hello,";
	yield " World";
  }
  
  const generator = helloGenerator();
  
  console.log(generator.next().value + generator.next().value); // Output: "Hello, World"

  function createGreeting(name) {
	return function() {
	  console.log(`Hey, ${name}`);
	};
  }
  
  const greetFrank = createGreeting("Frank");
  
  greetFrank(); // Output: "Hey, Frank"

  const person = {
	name: "Grace",
	sayHello: function() {
	  console.log(`Hello, ${this.name}`);
	}
  };
  
  person.sayHello(); // Output: "Hello, Grace"