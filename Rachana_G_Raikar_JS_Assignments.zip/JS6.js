//let and Const
const pi = 3.141592;
const name = "Alice";

console.log(pi); // Valid, accessing the constant
console.log(name); // Valid, accessing the constant


// Traditional function
function add(a, b) {
    return a + b;
  }
  
  // Arrow function
  const add1 = (a, b) => a + b;
  

//Template literals
console.log(`Hello, ${name}!`); // Hello, Alice!

//Destructuring Assignment
const person = { name: "John", age: 30 };
const { name1, age } = person;
console.log(name); // John

const colors = ["red", "green", "blue"];
const [firstColor, secondColor] = colors;
console.log(firstColor); // red

//Spread and RestOperators
const numbers = [1, 2, 3];
const newNumbers = [...numbers, 4, 5];
console.log(newNumbers); // [1, 2, 3, 4, 5]

const sum = (...args) => args.reduce((total, num) => total + num, 0);
console.log(sum(1, 2, 3)); // 6

//Default Parameters:
function greet(name = "Guest") {
    console.log(`Hello, ${name}!`);
  }
  greet(); // Hello, Guest!

//Object Shorthand
const age1= 25;
const person1 = { name: "Alice", age }; // { name: "Alice", age: 25 }

//classes
class Animal {
    constructor(name) {
      this.name = name;
    }
  
    speak() {
      console.log(`${this.name} makes a sound.`);
    }
  }
  
  const cat = new Animal("Cat");
  cat.speak(); // Cat makes a sound.

//Promises
const fetchData = () => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve("Data fetched!");
      }, 1000);
    });
  };
  
  fetchData()
    .then((data) => console.log(data))
    .catch((error) => console.error(error));

