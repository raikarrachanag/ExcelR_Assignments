// Array Methods with Numbers
const numbers = [1, 2, 3, 4, 5,6];

// 1. push() - Add an element to the end of the array
numbers.push(6);
console.log("After Push:", numbers);

// 2. pop() - Remove the last element from the array
numbers.pop();
console.log("After Pop", numbers);

// 3. shift() - Remove the first element from the array
numbers.shift();
console.log("After Shift", numbers);

// 4. unshift() - Add an element to the beginning of the array
numbers.unshift(0);
console.log("After unshift", numbers);


// Create a new array containing elements from index 2 to the end
const slicedArray = numbers.slice(1,4);

console.log("Sliced Array", slicedArray); 


const startIndex = numbers.indexOf(1, 1); // Start searching from index 1 (second occurrence of 1)
const index = numbers.indexOf(5, startIndex); // Search for the index of 5 starting from startIndex

console.log("Index Of 5", index); 

const removedElements = numbers.splice(0, 5, 0, 8, 9);

console.log("After Splice", numbers);      
console.log(removedElements); 

const numberToCheck = 3;

if (numbers.includes(numberToCheck)) {
  console.log(`3 exists in array :true`);
} else {
  console.log(`3 exists in array :false`);
}

const originalArray = [0, 8, 9, 4, 5, 6];

// Reverse the original array and add additional elements using concat
const reversed = originalArray.reverse();

console.log("After Reverse", reversed); 

// Sort the combined array in ascending order
const sortedArray = originalArray.sort((a, b) => a - b);

console.log("After Sort", sortedArray);

const originalString = "Javascript is awesome";

// Convert the string to uppercase
const uppercaseString = originalString.toUpperCase();

console.log("Uppercase:", uppercaseString); // Output: "JAVASCRIPT IS AWESOME"

// Convert the string to lowercase
const lowercaseString = originalString.toLowerCase();

console.log("LOWERCASE:", lowercaseString); // Output: "javascript is awesome"


const length = originalString.length;
console.log("Length:", length);

const substring = "is";

// Find the index of the substring "is"
const index1 = originalString.indexOf(substring);

console.log("Index of is ", index1); // Output: 11


// Extract the substring starting at index 0 and ending at index 10 (exclusive)
const substring1 = originalString.substring(4, 10);

console.log("Substring:", substring1); 

// Replace "awesome" with "matching"
const modifiedString = originalString.replace("awesome", "amazing");

console.log("Replaces String:",modifiedString); 


// Split the string into an array of words using space as the delimiter
const wordArray = originalString.split(" ");

console.log(wordArray); // Output: ["JavaScript", "is", "Awesome!"]
