package com.project44;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EmployeeManagementSystemAssignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemAssignment1Application.class, args);
		
			
	}

}
